document.addEventListener('DOMContentLoaded', () => {
   
    const allLinks = document.querySelectorAll('.sidebar-nav a');
    const hasSubmenuItems = document.querySelectorAll('.nav-item.has-submenu');

    allLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const currentItem = link.closest('.nav-item') || link.closest('.submenu-item');
           
            // 1. LIMPAR O ESTADO ATIVO de todos os itens (principal e submenu)
            document.querySelectorAll('.nav-item, .submenu-item').forEach(i => i.classList.remove('active'));

            // 2. LÓGICA DE ABERTURA/FECHAMENTO (apenas para itens 'has-submenu')
            if (currentItem.classList.contains('has-submenu')) {
                e.preventDefault(); // Impede que o link vá para outra página
               
                const wasOpen = currentItem.classList.contains('open');

                // A. Fechar todos os outros submenus abertos
                hasSubmenuItems.forEach(i => {
                    if (i !== currentItem && i.classList.contains('open')) {
                        i.classList.remove('open');
                        const icon = i.querySelector('i');
                        if (icon) {
                            icon.classList.remove('fa-minus');
                            icon.classList.add('fa-plus');
                        }
                    }
                });
               
                // B. Abrir/Fechar o submenu clicado
                if (!wasOpen) {
                    currentItem.classList.add('open', 'active'); // Abre e marca o pai como ativo
                   
                    // Altera o ícone para "menos"
                    const icon = currentItem.querySelector('i');
                    if (icon) {
                        icon.classList.remove('fa-plus');
                        icon.classList.add('fa-minus');
                    }
                } else {
                    currentItem.classList.remove('open');
                    // O ícone retorna a "mais" automaticamente pela classe 'open' ser removida
                    const icon = currentItem.querySelector('i');
                    if (icon) {
                        icon.classList.remove('fa-minus');
                        icon.classList.add('fa-plus');
                    }
                }

            } else {
                // 3. LÓGICA PARA ITENS NORMAIS (sem submenu ou sub-itens)

                currentItem.classList.add('active'); // Marca o item como ativo

                if (currentItem.classList.contains('submenu-item')) {
                    // Se for um sub-item, garante que o menu pai continue ativo e aberto
                    const parentSubmenu = currentItem.closest('.has-submenu');
                    if (parentSubmenu) {
                        parentSubmenu.classList.add('active');
                        parentSubmenu.classList.add('open');
                        // Garante que o ícone do pai seja o de 'menos'
                        const icon = parentSubmenu.querySelector('i');
                        if (icon) {
                            icon.classList.remove('fa-plus');
                            icon.classList.add('fa-minus');
                        }
                    }
                } else {
                    // Se for um item principal SEM submenu, fecha todos os submenus abertos
                    hasSubmenuItems.forEach(i => {
                        i.classList.remove('open');
                        const icon = i.querySelector('i');
                        if (icon) {
                            icon.classList.remove('fa-minus');
                            icon.classList.add('fa-plus');
                        }
                    });
                }
            }
        });
    });
   
    // Configura o primeiro item "Agendamento" como ativo ao carregar, conforme o layout
    document.querySelector('.nav-item:first-child').classList.add('active');

    // --- Funcionalidades de Cards (mantidas) ---
    const trainingCard = document.querySelector('.training-card');
    trainingCard.addEventListener('click', () => {
        alert('Redirecionando para o conteúdo de treinamento no Youtube...');
    });

    const supportCard = document.querySelector('.support-card');
    supportCard.addEventListener('click', () => {
        alert('Abrindo formulário de contato/chat de suporte...');
    });
});